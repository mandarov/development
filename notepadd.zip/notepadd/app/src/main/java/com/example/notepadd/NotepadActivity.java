package com.example.notepadd;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.notepadd.R;
import com.example.notepadd.database.DatabaseHelper;
import com.example.notepadd.models.Note;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NotepadActivity extends AppCompatActivity {
    private EditText titleEditText, textEditText;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notepad);

        titleEditText = findViewById(R.id.titleEditText);
        textEditText = findViewById(R.id.textEditText);
        databaseHelper = new DatabaseHelper(this);

        Button saveButton = findViewById(R.id.saveButton);
        Button homeButton = findViewById(R.id.homeButton);

        saveButton.setOnClickListener(v -> {
            String title = titleEditText.getText().toString().trim();
            String text = textEditText.getText().toString().trim();
            if (!title.isEmpty() && !text.isEmpty()) {
                String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                Note note = new Note(0, title, text, date);
                if (databaseHelper.addNote(note)) {
                    Toast.makeText(this, "Запись сохранена", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Ошибка сохранения", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            }
        });

        homeButton.setOnClickListener(v -> finish());
    }
}
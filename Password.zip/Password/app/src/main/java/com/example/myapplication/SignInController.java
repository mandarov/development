package com.example.myapplication;

public class SignInController {
    private final SignInForm parentController;

    public SignInController(SignInForm parentController) {
        this.parentController = parentController;
    }

    public void onClickSignIn() {

    }

    public void onClickSignUp() {

    }
}
